#!/bin/bash

sleep 1
conky -c $HOME/.Conky/revolutionary_clocks/rev_supermini/conkyrc &
exit 0

